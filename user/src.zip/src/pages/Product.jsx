import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import "./Product.css";

function Product() {
  const navigate = useNavigate();

  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);

  const [productsLoading, setProductsLoading] = useState(true);
  const [categoriesLoading, setCategoriesLoading] = useState(true);

  const [productsError, setProductsError] = useState("");

  // =========================
  // FETCH PRODUCTS
  // =========================

  const fetchProducts = async () => {
    try {
      setProductsLoading(true);
      setProductsError("");

      const response = await fetch("http://localhost:5000/api/products");

      const data = await response.json();

      if (response.ok) {
        setProducts(data);
      } else {
        setProductsError(data.message || "Unable to fetch products");
      }
    } catch (error) {
      console.log("Product Fetch Error:", error);

      setProductsError("Unable to load products. Please try again.");
    } finally {
      setProductsLoading(false);
    }
  };

  // =========================
  // FETCH CATEGORIES
  // =========================

  const fetchCategories = async () => {
    try {
      setCategoriesLoading(true);

      const response = await fetch("http://localhost:5000/api/category");

      const data = await response.json();

      if (response.ok) {
        setCategories(data);
      }
    } catch (error) {
      console.log("Category Fetch Error:", error);
    } finally {
      setCategoriesLoading(false);
    }
  };

  // =========================
  // CATEGORY NAME
  // =========================

  const getCategoryName = (categoryid) => {
    const category = categories.find(
      (item) => Number(item.categoryid) === Number(categoryid),
    );

    return category ? category.cname : "Unknown";
  };

  // =========================
  // CHECK LOGIN
  // =========================

  const checkLogin = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/session", {
        credentials: "include",
      });

      if (!response.ok) {
        return null;
      }

      const data = await response.json();

      if (data.loggedIn && data.user) {
        return data.user;
      }

      return null;
    } catch (error) {
      console.log("Session Check Error:", error);
      return null;
    }
  };

  // =========================
  // FLYING CART ANIMATION
  // =========================

  const startCartAnimation = (product, button) => {
    const cartButton = document.querySelector(".nav-cart");

    if (!cartButton) {
      console.log("Navbar cart button (.nav-cart) not found");
      return;
    }

    if (!button) {
      return;
    }

    const start = button.getBoundingClientRect();

    const end = cartButton.getBoundingClientRect();

    const flyingItem = document.createElement("div");

    flyingItem.className = "flying-cart-item";

    flyingItem.innerHTML = `
      <img
        src="http://localhost:5000/uploads/${product.photo}"
        alt="${product.pname}"
      />
    `;

    const startX = start.left + start.width / 2;

    const startY = start.top + start.height / 2;

    const endX = end.left + end.width / 2;

    const endY = end.top + end.height / 2;

    flyingItem.style.left = `${startX - 27}px`;

    flyingItem.style.top = `${startY - 27}px`;

    flyingItem.style.setProperty("--end-x", `${endX - startX}px`);

    flyingItem.style.setProperty("--end-y", `${endY - startY}px`);

    document.body.appendChild(flyingItem);

    setTimeout(() => {
      flyingItem.remove();
    }, 750);
  };

  // =========================
  // ADD TO CART
  // =========================

  const addToCart = async (product, event) => {
    try {
      // =========================
      // CHECK LOGIN
      // =========================

      const user = await checkLogin();

      if (!user) {
        navigate("/login");
        return;
      }

      // =========================
      // USER CART KEY
      // =========================

      const cartKey = `cart_${user.id}`;

      // =========================
      // GET OLD CART
      // =========================

      const oldCart = JSON.parse(localStorage.getItem(cartKey)) || [];

      // =========================
      // CHECK EXISTING PRODUCT
      // =========================

      const existingProduct = oldCart.find((item) => item._id === product._id);

      let updatedCart;

      // =========================
      // INCREASE QUANTITY
      // =========================

      if (existingProduct) {
        updatedCart = oldCart.map((item) =>
          item._id === product._id
            ? {
                ...item,
                quantity: Number(item.quantity || 1) + 1,
                rate: Number(item.rate || product.rate || 0),
              }
            : item,
        );
      }

      // =========================
      // ADD NEW PRODUCT
      // =========================
      else {
        updatedCart = [
          ...oldCart,
          {
            _id: product._id,
            productid: product.productid,
            categoryid: product.categoryid,
            pname: product.pname,
            description: product.description,
            rate: Number(product.rate || 0),
            photo: product.photo,
            quantity: 1,
          },
        ];
      }

      // =========================
      // SAVE CART
      // =========================

      localStorage.setItem(cartKey, JSON.stringify(updatedCart));

      console.log("Cart Saved:", updatedCart);

      // =========================
      // START ANIMATION
      // =========================

      startCartAnimation(product, event.currentTarget);

      // =========================
      // UPDATE NAVBAR CART
      // =========================

      window.dispatchEvent(new Event("cartUpdated"));

      // =========================
      // NON-BLOCKING MESSAGE
      // =========================

      showCartMessage(`${product.pname} added to cart`);
    } catch (error) {
      console.log("Add To Cart Error:", error);
    }
  };

  // =========================
  // CART MESSAGE
  // =========================

  const showCartMessage = (message) => {
    const oldMessage = document.querySelector(".cart-success-message");

    if (oldMessage) {
      oldMessage.remove();
    }

    const messageBox = document.createElement("div");

    messageBox.className = "cart-success-message";

    messageBox.innerText = message;

    document.body.appendChild(messageBox);

    setTimeout(() => {
      messageBox.classList.add("show");
    }, 10);

    setTimeout(() => {
      messageBox.classList.remove("show");

      setTimeout(() => {
        messageBox.remove();
      }, 300);
    }, 1800);
  };

  // =========================
  // USE EFFECT
  // =========================

  useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, []);

  // =========================
  // UI
  // =========================

  return (
    <>
      <Navbar />

      <section className="products-section">
        {/* =========================
            HEADING
        ========================= */}

        <div className="section-heading">
          <span>OUR SPECIALS</span>

          <h2>Popular Products</h2>

          <p>Taste the most loved items from our cafe.</p>
        </div>

        {/* =========================
            LOADING
        ========================= */}

        {productsLoading ? (
          <div className="products-loading">
            <div className="loading-spinner"></div>

            <h3>Loading Products...</h3>

            <p>Please wait while we fetch our delicious products.</p>
          </div>
        ) : productsError ? (
          /* =========================
             ERROR
          ========================= */

          <div className="products-empty">
            <div className="empty-icon">⚠️</div>

            <h3>Something went wrong</h3>

            <p>{productsError}</p>

            <button className="retry-btn" onClick={fetchProducts}>
              Try Again
            </button>
          </div>
        ) : products.length === 0 ? (
          /* =========================
             EMPTY
          ========================= */

          <div className="products-empty">
            <div className="empty-icon">☕</div>

            <h3>No Products Available</h3>

            <p>
              We don't have any products available right now. Please check again
              later.
            </p>
          </div>
        ) : (
          /* =========================
             PRODUCT GRID
          ========================= */

          <div className="product-grid">
            {products.map((product) => (
              <div className="product-card" key={product._id}>
                {/* IMAGE */}

                <div className="product-image">
                  <img
                    src={`http://localhost:5000/uploads/${product.photo}`}
                    alt={product.pname}
                  />
                </div>

                {/* INFO */}

                <div className="product-info">
                  <small>
                    {categoriesLoading
                      ? "Loading category..."
                      : getCategoryName(product.categoryid)}
                  </small>

                  <h3>{product.pname}</h3>

                  <p>{product.description}</p>

                  {/* BOTTOM */}

                  <div className="product-bottom">
                    <strong>₹{Number(product.rate) || 0}</strong>

                    <button
                      type="button"
                      className="add-cart-btn"
                      onClick={(e) => addToCart(product, e)}
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <Footer />
    </>
  );
}

export default Product;
