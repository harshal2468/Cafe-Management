import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import "./Productbycategory.css";

import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function Productbycategory() {
  // =========================
  // GET CATEGORY ID FROM URL
  // =========================

  const { categoryid } = useParams();

  const navigate = useNavigate();

  const [products, setProducts] = useState([]);
  const [categoryName, setCategoryName] = useState("");
  const [message, setMessage] = useState("");

  // =========================
  // FETCH PRODUCTS BY CATEGORY
  // =========================

  const fetchProducts = async () => {
    try {
      console.log("Selected Category ID:", categoryid);

      const response = await fetch(
        `http://localhost:5000/api/product/${categoryid}`,
      );

      const data = await response.json();

      console.log("Products:", data);

      if (response.ok) {
        setProducts(data);
      } else {
        alert(data.message || "Unable to fetch products");
      }
    } catch (error) {
      console.log("Product Fetch Error:", error);
    }
  };

  // =========================
  // FETCH CATEGORY NAME
  // =========================

  const fetchCategoryName = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/category");

      const data = await response.json();

      if (response.ok) {
        const category = data.find(
          (item) => Number(item.categoryid) === Number(categoryid),
        );

        if (category) {
          setCategoryName(category.cname);
        }
      }
    } catch (error) {
      console.log("Category Fetch Error:", error);
    }
  };

  // =========================
  // CHECK LOGIN
  // =========================

  const checkLogin = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/session", {
        credentials: "include",
      });

      return response.ok;
    } catch (error) {
      console.log("Session Check Error:", error);
      return false;
    }
  };

  // =========================
  // ADD TO CART
  // =========================
  const addToCart = async (product) => {
    try {
      const response = await fetch("http://localhost:5000/api/session", {
        credentials: "include",
      });

      const data = await response.json();

      if (!response.ok || !data.loggedIn) {
        setMessage("Please login first to add products to cart.");

        setTimeout(() => {
          setMessage("");
          navigate("/login");
        }, 1500);

        return;
      }

      const userId = data.user.id;

      // User-specific cart
      const cartKey = `cart_${userId}`;

      const cart = JSON.parse(localStorage.getItem(cartKey)) || [];

      const existingProduct = cart.find((item) => item._id === product._id);

      let updatedCart;

      if (existingProduct) {
        updatedCart = cart.map((item) =>
          item._id === product._id
            ? {
                ...item,
                quantity: item.quantity + 1,
              }
            : item,
        );
      } else {
        updatedCart = [
          ...cart,
          {
            ...product,
            quantity: 1,
          },
        ];
      }

      localStorage.setItem(cartKey, JSON.stringify(updatedCart));

      window.dispatchEvent(new Event("cartUpdated"));

      setMessage(`${product.pname} added to cart`);

      setTimeout(() => {
        setMessage("");
      }, 2000);
    } catch (error) {
      console.log("Add Cart Error:", error);
    }
  };

  // =========================
  // USE EFFECT
  // =========================

  useEffect(() => {
    if (categoryid) {
      fetchProducts();
      fetchCategoryName();
    }
  }, [categoryid]);

  // =========================
  // UI
  // =========================

  return (
    <>
      <Navbar />
      <Navbar />

      {message && (
        <div className="cart-toast">
          <span>✓</span>
          {message}
        </div>
      )}

      <section className="products-section">
        {/* =========================
            HEADING
        ========================= */}

        <div className="section-heading">
          <span>OUR MENU</span>

          <h2>{categoryName || "Menu"}</h2>

          <p>Delicious items from this category.</p>
        </div>

        {/* =========================
            PRODUCTS
        ========================= */}

        <div className="product-grid">
          {products.length > 0 ? (
            products.map((product) => (
              <div className="product-card" key={product._id}>
                {/* PRODUCT IMAGE */}

                <div className="product-image">
                  <img
                    src={`http://localhost:5000/uploads/${product.photo}`}
                    alt={product.pname}
                  />
                </div>

                {/* PRODUCT INFO */}

                <div className="product-info">
                  <small>{categoryName}</small>

                  <h3>{product.pname}</h3>

                  <p>{product.description}</p>

                  {/* BOTTOM */}

                  <div className="product-bottom">
                    <strong>₹{product.rate}</strong>

                    {/* ADD TO CART */}

                    <button
                      className="add-cart-btn"
                      onClick={() => addToCart(product)}
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p>No products found in this category.</p>
          )}
        </div>
      </section>

      <Footer />
    </>
  );
}

export default Productbycategory;
